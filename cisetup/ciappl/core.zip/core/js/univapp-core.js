$(document).ready(function () {
	$("#open").click(function () {
		$("div#panel").slideDown("slow");
	});
	$("#close").click(function () {
		$("div#panel").slideUp("slow");
	});
	$("#toggle a").click(function () {
		$("#toggle a").toggle();
	});
});
jQuery(document).bind('keydown', 'esc', function (e) {
	if ($("#open").attr("style") == 'display: none;') {
		$("div#panel").slideUp("slow");
		$("#toggle a").toggle();
	}
});
